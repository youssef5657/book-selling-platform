﻿namespace mynewproject3.Views.Shared
{
    public class Class
    {
    }
}
