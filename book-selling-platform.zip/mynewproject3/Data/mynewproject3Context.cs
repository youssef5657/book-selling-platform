﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using mynewproject3.Models;

namespace mynewproject3.Data
{
    public class mynewproject3Context : DbContext
    {
        public mynewproject3Context (DbContextOptions<mynewproject3Context> options)
            : base(options)
        {
        }

        public DbSet<mynewproject3.Models.book> book { get; set; } 
        public DbSet<mynewproject3.Models.usersaccounts> usersaccounts { get; set; } 
        public DbSet<mynewproject3.Models.orders> orders { get; set; } 

        public DbSet<mynewproject3.Models.report> report { get; set; } 
    }
}
