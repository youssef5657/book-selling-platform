﻿namespace mynewproject3.Models
{
    public class report
    {
        public int Id { get; set; }
        public string customername { get; set; }
        public int total { get; set; }

    }
}
